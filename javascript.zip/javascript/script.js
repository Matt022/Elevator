let elevator = {
    movement: 'up, down, stopped',
    doorsOpen: true,
}


fillTheQuestionsAndAnswers(randomQuestion)

